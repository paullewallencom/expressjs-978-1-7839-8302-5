var app = require('./src/lib/app')
app.listen(3000)