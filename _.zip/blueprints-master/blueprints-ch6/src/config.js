module.exports = {
  db: {
    mongo_url:      'mongodb://localhost/links'
  }
};
