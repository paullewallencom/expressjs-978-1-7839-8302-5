var app = require('./src/app.js');
app.listen(3000);
console.log('Koa app listening on port 3000');
