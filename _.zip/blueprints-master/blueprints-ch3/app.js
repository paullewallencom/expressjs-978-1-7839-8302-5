var app = require('./src/lib/app');
app.listen(8000);
console.log('Express listening on port 8000');
