module.exports = {
  MIN_ROWS: 6,
  MIN_COLUMNS: 7
};
